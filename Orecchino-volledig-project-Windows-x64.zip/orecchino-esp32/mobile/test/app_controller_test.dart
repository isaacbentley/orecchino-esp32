// app_controller_test.dart — the BLE path end to end with a fake transport:
// pairing pins a verified detector and starts feed / time / position / sync;
// the phone's position goes only to a verified, pinned detector.
//
// Part of orecchino-esp32. SPDX-License-Identifier: GPL-3.0-or-later

import 'dart:convert';

import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:orecchino_mobile/app/app_controller.dart';
import 'package:orecchino_mobile/core/ble/ble_service.dart';
import 'package:orecchino_mobile/core/location/location_service.dart';
import 'package:orecchino_mobile/core/traffic/adsb_source.dart';
import 'package:orecchino_mobile/data/db.dart';

import 'support/fakes.dart';

class FakeLocation extends LocationService {
  PhoneLocation? fix;
  FakeLocation(this.fix);
  @override
  Future<void> start() async {}
  @override
  PhoneLocation? get currentLocation => fix;
  @override
  double? get headingDeg => 0;
}

void main() {
  late FakeTransport t;
  late AppController app;

  setUp(() async {
    t = FakeTransport();
    // Keep all ADS-B requests local to the test.
    app = AppController(
      db: AppDatabase(NativeDatabase.memory()),
      ble: BleService(transport: t, pairTimeout: const Duration(seconds: 2)),
      location: FakeLocation(const PhoneLocation(lat: 37.8039, lon: -122.464, accuracyM: 5, timeMs: 0)),
      adsb: AdsbSource(client: MockClient((_) async => http.Response('{"ac":[]}', 200))),
      startTimers: false,
    );
    await app.start();
  });

  tearDown(() => app.dispose());

  Future<void> settle() async {
    for (var i = 0; i < 5; i++) {
      await Future<void>.delayed(Duration.zero);
    }
  }

  test('pairing a verified detector pins it, then feed, time, position and sync', () async {
    final p = t.peers['A'] = FakePeer('A');
    expect(await app.pair('A', 'Orecchino-1A2B'), isTrue);
    await settle();
    final cmds = p.lines.map((l) => jsonDecode(l) as Map<String, dynamic>).toList();
    expect(cmds.map((c) => c['cmd']).toList(), ['feed', 'set_time', 'set_home', 'log_get']);
    expect(cmds[0]['on'], isTrue);
    expect(cmds[2]['lat'], 37.8039);
    expect(cmds[2]['src'], 'phone');
    expect(cmds[3]['since'], 0);
    final d = (await app.db.getDetector('A'))!;
    expect(d.bonded, isTrue);
    expect(d.board, 'lilygo-t5-epaper-s3-pro');
    expect(app.detectorReady, isTrue);

    // Every 60 s: time and position again.
    p.writes.clear();
    await app.pushContext();
    expect(p.lines.map((l) => (jsonDecode(l) as Map<String, dynamic>)['cmd']).toList(), ['set_time', 'set_home']);
  });

  test('history resumes from the stored cursor on the next connection', () async {
    final p = t.peers['A'] = FakePeer('A');
    await app.pair('A', 'Orecchino');
    await settle();
    p.notify('{"type":"log","seq":0,"i":0,"active":false,"uas":"X","mac":"AA:AA:AA:AA:AA:AA","first":1,"last":2,'
        '"dur":1,"peak_rssi":-60,"auth_state":"none","tfr":false,"emerg":false,"msgs":1}\n');
    p.notify('{"type":"log","seq":null,"i":null,"active":true,"uas":"Y","mac":"BB:BB:BB:BB:BB:BB","first":1,"last":2,'
        '"dur":1,"peak_rssi":-60,"auth_state":"none","tfr":false,"emerg":false,"msgs":1}\n');
    p.notify('{"type":"log_done","n":1,"live":1,"total":1,"clock":true,"next":1,"oldest":0}\n');
    for (var i = 0; i < 20 && app.sync.isSyncing; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 5));
    }
    expect(app.sync.isSyncing, isFalse);
    expect((await app.db.getDetector('A'))!.lastSyncSeq, 1);

    await app.disconnect();
    final p2 = t.peers['A'] = FakePeer('A');
    await app.connectPinned('A');
    await settle();
    final logGet = p2.lines.map((l) => jsonDecode(l) as Map<String, dynamic>).firstWhere((c) => c['cmd'] == 'log_get');
    expect(logGet['since'], 1);
    expect((await app.db.getDetector('A'))!.lastSyncSeq, 1); // the re-pin kept the cursor
  });

  test('log_cleared with the new log id: the next sync is of that log, without a second restart', () async {
    final p = t.peers['A'] = FakePeer('A');
    await app.pair('A', 'Orecchino');
    await settle();
    Future<void> synced() async {
      for (var i = 0; i < 40 && app.sync.isSyncing; i++) {
        await Future<void>.delayed(const Duration(milliseconds: 5));
      }
      expect(app.sync.isSyncing, isFalse);
    }

    int logGets() => p.lines.where((l) => l.contains('"log_get"')).length;
    p.notify('{"type":"log_done","n":0,"live":0,"total":3,"clock":true,"next":3,"oldest":0,"log_id":7}\n');
    await synced();
    expect((await app.db.getDetector('A'))!.logId, 7);
    expect(logGets(), 1);

    p.notify('{"type":"log_cleared","log_id":8}\n');
    for (var i = 0; i < 40 && logGets() < 2; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 5));
    }
    expect(logGets(), 2);
    expect(app.sync.isSyncing, isTrue);
    p.notify('{"type":"log_done","n":0,"live":0,"total":1,"clock":true,"next":1,"oldest":0,"log_id":8}\n');
    await synced();
    final d = (await app.db.getDetector('A'))!;
    expect(d.logEpoch, 1);
    expect(d.logId, 8);
    expect(d.lastSyncSeq, 1);
    expect(logGets(), 2); // the id matched: no restart from oldest
    expect(app.sync.lastProgress.logCleared, isFalse);
  });

  test('a failed "Pair" of a second detector goes back to the pinned one', () async {
    final t2 = FakeTransport();
    final app2 = AppController(
      db: AppDatabase(NativeDatabase.memory()),
      ble: BleService(transport: t2, pairTimeout: const Duration(seconds: 2)),
      location: FakeLocation(null),
      adsb: AdsbSource(client: MockClient((_) async => http.Response('{"ac":[]}', 200))),
      // Real timers: the reconnect is one.
    );
    await app2.start();
    t2.peers['A'] = FakePeer('A');
    expect(await app2.pair('A', 'T5'), isTrue);
    expect(app2.detectorReady, isTrue);
    expect(app2.reconnectPending, isFalse);
    // Pairing B tears A's link down; B turns out not to be an Orecchino.
    t2.peers['B'] = FakePeer('B', info: '{"fw":"other","proto":1}');
    expect(await app2.pair('B', 'Nordic_UART'), isFalse);
    expect(app2.detectorReady, isFalse);
    expect(app2.reconnectPending, isTrue);
    app2.dispose();
  });

  test('a device that fails verification gets nothing, and is not pinned', () async {
    final p = t.peers['X'] = FakePeer('X', info: '{"fw":"nus-echo","proto":1}');
    expect(await app.pair('X', 'Nordic_UART'), isFalse);
    await app.pushContext();
    expect(p.writes, isEmpty);
    expect(await app.db.getDetector('X'), isNull);
  });

  test('a link the app did not verify and pin never receives the position', () async {
    final p = t.peers['B'] = FakePeer('B');
    await app.ble.connect('B'); // connected and encrypted, but not paired through the app
    expect(app.ble.isReady, isTrue);
    expect(app.detectorReady, isFalse);
    await app.pushContext();
    await app.pushTraffic();
    expect(p.writes, isEmpty);
  });

  test('after the link drops, nothing is sent and the sync stops', () async {
    final p = t.peers['A'] = FakePeer('A');
    await app.pair('A', 'Orecchino');
    await settle();
    expect(app.sync.isSyncing, isTrue);
    p.drop();
    await settle();
    expect(app.detectorReady, isFalse);
    expect(app.sync.isSyncing, isFalse);
    final n = p.writes.length;
    await app.pushContext();
    expect(p.writes.length, n);
  });

  test('pinned detectors are reconnected with their board checked', () async {
    t.peers['A'] = FakePeer('A');
    await app.pair('A', 'Orecchino');
    await app.disconnect();
    expect(app.detectorReady, isFalse);
    // Same ID, different board: refused, and never given the position.
    final impostor = t.peers['A'] = FakePeer('A',
        info: '{"fw":"orecchino","ver":"0.6.0","board":"lilygo-t-embed","caps":["log"],"proto":1}');
    await app.connectPinned('A');
    expect(app.detectorReady, isFalse);
    expect(app.ble.error, contains('not the lilygo-t5-epaper-s3-pro'));
    expect(impostor.writes, isEmpty);
  });

  test('a verified traffic-capable T5 stays idle until its first Remote ID message', () async {
    final transport = FakeTransport();
    final peer = transport.peers['A'] = FakePeer('A', info: t5Info.replaceFirst('"tiles"]', '"tiles","traffic"]'));
    final gets = <Uri>[];
    final controller = AppController(
      db: AppDatabase(NativeDatabase.memory()),
      ble: BleService(transport: transport, pairTimeout: const Duration(seconds: 2)),
      location: FakeLocation(const PhoneLocation(lat: 37.8039, lon: -122.464, accuracyM: 5, timeMs: 0)),
      adsb: AdsbSource(client: MockClient((req) async {
        gets.add(req.url);
        return http.Response('{"ac":[]}', 200);
      })),
    );
    addTearDown(controller.dispose);
    await controller.start();
    expect(await controller.pair('A', 'Orecchino'), isTrue);
    await settle();
    expect(controller.detectorInfo?.has('traffic'), isTrue);
    expect(controller.adsbInterval, isNull);
    expect(controller.canRefreshTraffic, isFalse);
    await controller.refreshTraffic();
    expect(gets, isEmpty);

    peer.notify('{"type":"hb","up":12345,"rid":0}\n');
    await settle();
    expect(gets, isEmpty);
    peer.notify('{"type":"rid","src":"ble","mac":"AA:BB:CC:DD:EE:01",'
        '"basic_id":[{"id_type":1,"ua_type":2,"uas_id":"TEST-BLE-DETECTION"}]}\n');
    await settle();
    expect(controller.tracker.contacts.single.hasPosition, isFalse);
    expect(gets.single.path, '/v2/point/37.80/-122.46/6');
    expect(peer.lines.any((line) => line.contains('"cmd":"traffic_done"')), isTrue);
  });

  test('forget unpins: no automatic connection afterwards', () async {
    t.peers['A'] = FakePeer('A');
    await app.pair('A', 'Orecchino');
    await app.forget('A');
    expect((await app.db.getDetector('A'))!.bonded, isFalse);
    final before = t.connects;
    await app.connectPinned('A');
    expect(t.connects, before);
  });
}
