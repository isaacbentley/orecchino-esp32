// uas_models.dart — make and model names for CTA-2063-A serial numbers: the
// first four characters name the maker; DJI's next three name the model.
// A copy of tools/uas_models.json (the source of truth for the firmware and
// the Mac app); test/uas_models_test.dart fails when the two differ.
//
// Part of orecchino-esp32. SPDX-License-Identifier: GPL-3.0-or-later

abstract final class UasModels {
  static const manufacturers = <String, String>{
    '1198': 'Freefly Systems',
    '1581': 'DJI',
    '1585': 'Parrot',
    '1596': 'DJI',
    '1647': 'Skydio',
    '1689': 'Autel Robotics',
    '1710': 'Yuneec',
    '1711': 'Teal Drones',
    '1738': 'Wingtra',
  };
  static const models = <String, String>{
    '1581F0M6': 'DJI Mavic 2 Zoom',
    '1581F0UY': 'DJI Phantom 4 RTK',
    '1581F11V': 'DJI Phantom 4 Pro V2.0',
    '1581F163': 'DJI Mavic 2 Pro',
    '1581F1WN': 'DJI Mavic Air 2 (MA2UE1N)',
    '1581F1ZN': 'DJI Matrice 300 RTK',
    '1581F37Q': 'DJI FPV',
    '1581F3N3': 'DJI Mavic Air 2 (MA2UE3W)',
    '1581F3YT': 'DJI Air 2S',
    '1581F446': 'DJI Agras T10 / T30',
    '1581F45T': 'DJI Mavic 3',
    '1581F4BN': 'DJI Matrice 30',
    '1581F4GC': 'DJI Mavic 2 Enterprise Advanced',
    '1581F4QW': 'DJI Avata',
    '1581F4QZ': 'DJI Mavic 3 Cine',
    '1581F4XF': 'DJI Mini 3 Pro',
    '1581F4Z4': 'DJI Inspire 3',
    '1581F574': 'DJI Agras T20P / T40',
    '1581F5BK': 'DJI Matrice 30T',
    '1581F5BL': 'DJI Matrice 30 (Dock)',
    '1581F5BM': 'DJI Matrice 30T (Dock)',
    '1581F5FH': 'DJI Mavic 3 Enterprise',
    '1581F5FJ': 'DJI Mavic 3 Thermal',
    '1581F5FK': 'DJI Mavic 3 Multispectral',
    '1581F5YH': 'DJI Mini 3',
    '1581F62H': 'DJI Matrice 30T (EU/KR)',
    '1581F67P': 'DJI Mavic 3 Classic',
    '1581F67Q': 'DJI Mavic 3 Pro',
    '1581F6BU': 'DJI Agras T50 / T25',
    '1581F6CD': 'DJI Mini 2 SE',
    '1581F6GK': 'DJI Matrice 350 RTK',
    '1581F6L5': 'DJI Mini 3 Pro',
    '1581F6MK': 'DJI Mavic 3 Pro Cine',
    '1581F6N8': 'DJI Air 3',
    '1581F6Q8': 'DJI Matrice 3TD',
    '1581F6QA': 'DJI Matrice 3D',
    '1581F6W8': 'DJI Avata 2',
    '1581F6Z9': 'DJI Mini 4 Pro',
    '1581F7C6': 'DJI FlyCart 30',
    '1581F7FV': 'DJI Matrice 4E',
    '1581F7K3': 'DJI Matrice 4T',
    '1581F836': 'DJI Agras T25P',
    '1581F87L': 'DJI Neo',
    '1581F895': 'DJI Air 3S',
    '1581F8DB': 'DJI Matrice 400',
    '1581F8HG': 'DJI Matrice 4TD',
    '1581F8HH': 'DJI Matrice 4D',
    '1581F8LQ': 'DJI Mavic 4 Pro (64 GB)',
    '1581F8PJ': 'DJI Mini 4K',
    '1581F8ZL': 'DJI Agras T100',
    '1581F8ZX': 'DJI Agras T70P',
    '1581F986': 'DJI Mavic 4 Pro (512 GB)',
    '1581F9DE': 'DJI Mini 5 Pro',
    '1581FA6Q': 'DJI Neo 2',
    '1581FA8J': 'DJI Avata 360 (DVN3XT)',
    '1581FAN4': 'DJI FlyCart 100',
    '1581FANL': 'DJI Mini 5 Pro (enhanced transmission)',
    '1581FB34': 'Lito X1',
    '1581FBEX': 'DJI M3TA',
    '1581FBLK': 'DJI Avata 360 (DVN3NT)',
  };

  /// The maker for a serial-number UAS ID, when its 4-character code is known.
  static String? manufacturer(String serial) =>
      serial.length < 5 ? null : manufacturers[serial.substring(0, 4).toUpperCase()];

  /// The model for a serial-number UAS ID, when its 8-character prefix is known.
  static String? model(String serial) => serial.length < 8 ? null : models[serial.substring(0, 8).toUpperCase()];
}
