#include <stdint.h>
#include "epd_board.h"
#include "epdiy.h"

#include "../output_common/render_method.h"
#include "../output_lcd/lcd_driver.h"
#include "epd_board_i2c.h"
#include "esp_log.h"
#include "pca9555.h"
#include "tps65185.h"

#include <driver/gpio.h>
#include <sdkconfig.h>

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

// Make this compile von the ESP32 without ifdefing the whole file
#ifndef CONFIG_IDF_TARGET_ESP32S3
#define GPIO_NUM_40 -1
#define GPIO_NUM_41 -1
#define GPIO_NUM_42 -1
#define GPIO_NUM_43 -1
#define GPIO_NUM_44 -1
#define GPIO_NUM_45 -1
#define GPIO_NUM_46 -1
#define GPIO_NUM_47 -1
#define GPIO_NUM_48 -1
#endif

#define CFG_SCL GPIO_NUM_40
#define CFG_SDA GPIO_NUM_39
#define CFG_INTR GPIO_NUM_38

#define CFG_PIN_OE (PCA_PIN_PC10 >> 8)
#define CFG_PIN_MODE (PCA_PIN_PC11 >> 8)
#define __CFG_PIN_STV (PCA_PIN_PC12 >> 8)
#define CFG_PIN_PWRUP (PCA_PIN_PC13 >> 8)
#define CFG_PIN_VCOM_CTRL (PCA_PIN_PC14 >> 8)
#define CFG_PIN_WAKEUP (PCA_PIN_PC15 >> 8)
#define CFG_PIN_PWRGOOD (PCA_PIN_PC16 >> 8)
#define CFG_PIN_INT (PCA_PIN_PC17 >> 8)

#define D15 GPIO_NUM_47
#define D14 GPIO_NUM_21
#define D13 GPIO_NUM_14
#define D12 GPIO_NUM_13
#define D11 GPIO_NUM_12
#define D10 GPIO_NUM_11
#define D9 GPIO_NUM_10
#define D8 GPIO_NUM_9

#define D7 GPIO_NUM_8
#define D6 GPIO_NUM_18
#define D5 GPIO_NUM_17
#define D4 GPIO_NUM_16
#define D3 GPIO_NUM_15
#define D2 GPIO_NUM_7
#define D1 GPIO_NUM_6
#define D0 GPIO_NUM_5

/* Control Lines */
#define CKV GPIO_NUM_48
#define STH GPIO_NUM_41
#define LEH GPIO_NUM_42
#define STV GPIO_NUM_45

/* Edges */
#define CKH GPIO_NUM_4

typedef struct {
    epd_board_i2c_context_t i2c;
    bool pwrup;
    bool vcom_ctrl;
    bool wakeup;
    bool others[8];
} epd_config_register_t;

static const epd_board_i2c_bus_config_t board_i2c_config = {
    .port = I2C_NUM_0,
    .sda_io_num = CFG_SDA,
    .scl_io_num = CFG_SCL,
    .bus_speed_hz = 100000,
};

/** The VCOM voltage to use. */
static int vcom = 1600;

static epd_config_register_t config_reg;

static bool interrupt_done = false;

static void IRAM_ATTR interrupt_handler(void* arg) {
    interrupt_done = true;
}

static lcd_bus_config_t lcd_config = {
    .clock = CKH,
    .ckv = CKV,
    .leh = LEH,
    .start_pulse = STH,
    .stv = STV,
    .data[0] = D0,
    .data[1] = D1,
    .data[2] = D2,
    .data[3] = D3,
    .data[4] = D4,
    .data[5] = D5,
    .data[6] = D6,
    .data[7] = D7,
    .data[8] = D8,
    .data[9] = D9,
    .data[10] = D10,
    .data[11] = D11,
    .data[12] = D12,
    .data[13] = D13,
    .data[14] = D14,
    .data[15] = D15,
};

static void epd_board_init(uint32_t epd_row_width, const EpdInitConfig* init_config) {
    gpio_hold_dis(CKH);  // free CKH after wakeup

    ESP_ERROR_CHECK(epd_board_i2c_init(&config_reg.i2c, &board_i2c_config, init_config, true, true)
    );
    config_reg.pwrup = false;
    config_reg.vcom_ctrl = false;
    config_reg.wakeup = false;
    for (int i = 0; i < 8; i++) {
        config_reg.others[i] = false;
    }

    gpio_set_direction(CFG_INTR, GPIO_MODE_INPUT);
    gpio_set_intr_type(CFG_INTR, GPIO_INTR_NEGEDGE);

    ESP_ERROR_CHECK(gpio_install_isr_service(ESP_INTR_FLAG_EDGE));

    ESP_ERROR_CHECK(gpio_isr_handler_add(CFG_INTR, interrupt_handler, (void*)CFG_INTR));

    // set all epdiy lines to output except TPS interrupt + PWR good
    ESP_ERROR_CHECK(pca9555_set_config(config_reg.i2c.pca, CFG_PIN_PWRGOOD | CFG_PIN_INT, 1));

    const EpdDisplay_t* display = epd_get_display();

    LcdEpdConfig_t config = {
        .pixel_clock = display->bus_speed * 1000 * 1000,
        .ckv_high_time = 60,
        .line_front_porch = 4,
        .le_high_time = 4,
        .bus_width = display->bus_width,
        .bus = lcd_config,
    };
    epd_lcd_init(&config, display->width, display->height);
}

static void epd_board_deinit() {
    epd_lcd_deinit();

    ESP_ERROR_CHECK(pca9555_set_config(
        config_reg.i2c.pca, CFG_PIN_PWRGOOD | CFG_PIN_INT | CFG_PIN_VCOM_CTRL | CFG_PIN_PWRUP, 1
    ));

    int tries = 0;
    while (!((pca9555_read_input(config_reg.i2c.pca, 1) & 0xC0) == 0x80)) {
        if (tries >= 50) {
            ESP_LOGE("epdiy", "failed to shut down TPS65185!");
            break;
        }
        tries++;
        vTaskDelay(1);
    }

    // Not sure why we need this delay, but the TPS65185 seems to generate an interrupt after some
    // time that needs to be cleared.
    vTaskDelay(50);
    pca9555_read_input(config_reg.i2c.pca, 0);
    pca9555_read_input(config_reg.i2c.pca, 1);
    epd_board_i2c_deinit(&config_reg.i2c);

    gpio_uninstall_isr_service();
}

static void epd_board_set_ctrl(epd_ctrl_state_t* state, const epd_ctrl_state_t* const mask) {
    uint8_t value = 0x00;
    if (mask->ep_output_enable || mask->ep_mode || mask->ep_stv) {
        if (state->ep_output_enable)
            value |= CFG_PIN_OE;
        if (state->ep_mode)
            value |= CFG_PIN_MODE;
        // if (state->ep_stv) value |= CFG_PIN_STV;
        if (config_reg.pwrup)
            value |= CFG_PIN_PWRUP;
        if (config_reg.vcom_ctrl)
            value |= CFG_PIN_VCOM_CTRL;
        if (config_reg.wakeup)
            value |= CFG_PIN_WAKEUP;

        esp_err_t err = pca9555_set_value(config_reg.i2c.pca, value, 1);
        if (err != ESP_OK) {
            ESP_LOGE("epdiy", "pca9555_set_value failed: %s", esp_err_to_name(err));
            // retry once, abort if it fails again
            ESP_ERROR_CHECK(pca9555_set_value(config_reg.i2c.pca, value, 1));
        }
    }
}

static void printPowerGoodStatus() {
    // Read the Power Good Status register at address 0x0F
    uint8_t pgStatus = tps_read_register(config_reg.i2c.tps, TPS_REG_PG);

    // Extract each Power Good status bit
    uint8_t vb_pg = (pgStatus >> 7) & 0x01;
    uint8_t vddh_pg = (pgStatus >> 6) & 0x01;
    uint8_t vn_pg = (pgStatus >> 5) & 0x01;
    uint8_t vpos_pg = (pgStatus >> 4) & 0x01;
    uint8_t vee_pg = (pgStatus >> 3) & 0x01;
    uint8_t vneg_pg = (pgStatus >> 1) & 0x01;

    // Log the Power Good Status
    ESP_LOGI("epdiy", "Power Good Status: 0x%02X", pgStatus);
    ESP_LOGI("epdiy", "VB_PG: %d", vb_pg);
    ESP_LOGI("epdiy", "VDDH_PG: %d", vddh_pg);
    ESP_LOGI("epdiy", "VN_PG: %d", vn_pg);
    ESP_LOGI("epdiy", "VPOS_PG: %d", vpos_pg);
    ESP_LOGI("epdiy", "VEE_PG: %d", vee_pg);
    ESP_LOGI("epdiy", "VNEG_PG: %d", vneg_pg);
}

static void epd_board_poweron(epd_ctrl_state_t* state) {
    epd_ctrl_state_t mask = {
        .ep_output_enable = true,
        .ep_mode = true,
        .ep_stv = true,
    };
    state->ep_stv = true;
    state->ep_mode = false;
    state->ep_output_enable = true;
    config_reg.vcom_ctrl = true;
    epd_board_set_ctrl(state, &mask);
    vTaskDelay(10);

    int retry_count = 0;
    bool pwr_good_received = false;

    while (retry_count < 30) {
        // Turn on wakeup and pwrup
        config_reg.wakeup = true;
        config_reg.pwrup = true;
        epd_board_set_ctrl(state, &mask);

        // Give the IC time to power up and set lines
        vTaskDelay(100);

        // Check for PWR_GOOD signal within 100ms
        if (pca9555_read_input(config_reg.i2c.pca, 1) & CFG_PIN_PWRGOOD) {
            pwr_good_received = true;
            printPowerGoodStatus();
            break;
        } else {
            printPowerGoodStatus();
        }

        // Turn off wakeup and pwrup
        config_reg.wakeup = false;
        config_reg.pwrup = false;
        epd_board_set_ctrl(state, &mask);

        // Wait for 10ms before retrying
        vTaskDelay(100);
        retry_count++;
    }

    if (!pwr_good_received) {
        ESP_LOGE(
            "epdiy", "PWR_GOOD signal not received after 30 retries, internal rails may not be OK"
        );
        printPowerGoodStatus();
        return;
    }

    ESP_ERROR_CHECK(tps_write_register(config_reg.i2c.tps, TPS_REG_ENABLE, 0x3F));

    tps_set_vcom(config_reg.i2c.tps, vcom);

    state->ep_sth = true;
    mask = (const epd_ctrl_state_t){
        .ep_sth = true,
    };
    epd_board_set_ctrl(state, &mask);

    int tries = 0;
    while (!((tps_read_register(config_reg.i2c.tps, TPS_REG_PG) & 0xFA) == 0xFA)) {
        if (tries >= 500) {
            ESP_LOGE(
                "epdiy",
                "Power enable failed! PG status: %X",
                tps_read_register(config_reg.i2c.tps, TPS_REG_PG)
            );
            printPowerGoodStatus();
            return;
        }
        tries++;
        vTaskDelay(1);
    }
}

static void epd_board_poweroff(epd_ctrl_state_t* state) {
    epd_ctrl_state_t mask = {
        .ep_stv = true,
        .ep_output_enable = true,
        .ep_mode = true,
    };
    config_reg.vcom_ctrl = false;
    config_reg.pwrup = false;
    state->ep_stv = false;
    state->ep_output_enable = false;
    state->ep_mode = false;
    epd_board_set_ctrl(state, &mask);
    vTaskDelay(1);
    config_reg.wakeup = false;
    epd_board_set_ctrl(state, &mask);
}

static float epd_board_ambient_temperature() {
    return 20;
}

static void set_vcom(int value) {
    vcom = value;
}

const EpdBoardDefinition sverio_paperboard_v1 = {
    .init = epd_board_init,
    .deinit = epd_board_deinit,
    .set_ctrl = epd_board_set_ctrl,
    .poweron = epd_board_poweron,
    .poweroff = epd_board_poweroff,

    .get_temperature = epd_board_ambient_temperature,
    .set_vcom = set_vcom,

    // unimplemented for now, but shares v6 implementation
    .gpio_set_direction = NULL,
    .gpio_read = NULL,
    .gpio_write = NULL,
};
