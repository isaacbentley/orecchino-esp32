// On-device track table, shared by every receiver with a screen. Header-only
// so a board sketch gets it by including rx_core.h — Arduino only compiles
// .cpp files that live inside the sketch directory.
//
// Keyed by UAS ID when known, else MAC; LRU-evicted by last_seen when full
// (never clobbers a fixed slot — the classic reference-receiver bug).
#pragma once
#include <Arduino.h>
#include "odid_decode.h"

#define TRK_MAX      16
#define TRK_EXPIRE_MS 600000UL
#define TRK_ALT_MACS 4    // other addresses remembered per contact

// Authentication pages collected across frames for one contact (see
// tracker_ingest in rx_core.h); mirrors the auth fields of OdidUas.
struct OdidAuthAssembly {
  bool     has_basic_raw;
  uint8_t  basic_raw[25];
  bool     has_auth;
  uint8_t  auth_type;
  uint8_t  auth_last_page;
  uint8_t  auth_len;
  uint32_t auth_ts;
  uint16_t auth_pages_seen;
  bool     verified;          // the pages held form a complete, verified set
  bool     verify_due;        // something changed since the last verdict
  uint32_t verify_ms;         // when a signature was last checked (0: never)
  uint8_t  auth_data[ODID_AUTH_MAX_BYTES];
};

struct Track {
  bool     used;
  uint8_t  mac[6];
  uint8_t  alt_macs[TRK_ALT_MACS][6];  // earlier addresses of the same aircraft
  uint8_t  alt_mac_count;
  char     uas[41];     // the identity the contact is keyed on (a serial when it has one)
  uint8_t  uas_type;    // ODID ID type of uas: 0 none yet, 2 a CAA registration heard
                        // alone, anything else a serial / UUID / session ID
  char     uas2[41];    // its CAA registration, when it also sends a serial (F3411
                        // allows both; BLE4 sends them in separate frames)
  uint8_t  ua_type;     // ODID UA type from the Basic ID, 0 unknown
  int8_t   rssi;
  uint8_t  src_mask;    // bit0 wifi, bit1 nan, bit2 ble
  uint8_t  fmt;         // bit0 ASTM F3411 seen, bit1 GB 46750-2025 seen
  char     ssid[33];    // beacon SSID, when Wi-Fi (DJI: "RID-" + serial)
  uint8_t  ssid_check;  // 0 n/a, 1 SSID serial matches the Basic ID, 2 it differs
  uint8_t  status;      // ODID operational status; 3 = emergency
  bool     has_pos;
  double   lat, lon;
  float    height;      // m, NAN when unknown; see height_ref
  float    alt_geo;     // m above the WGS-84 ellipsoid (ODID geodetic altitude), NAN
                        // when unknown: what traffic.h compares with ADS-B alt_geom
  uint8_t  height_ref;  // ODID height type: 0 above takeoff, 1 above ground
  float    speed;       // m/s, NAN when unknown
  float    heading;     // deg true, NAN when unknown
  // Authentication verification, mirroring OdidAuthState:
  // 0 none, 1 partial, 2 unknown key, 3 ID signature valid, 4 invalid,
  // 5 signed with the published test key (proves nothing about the ID).
  uint8_t  auth_state;
  OdidAuthAssembly auth_asm;
  bool     in_tfr;      // position inside a pushed TFR polygon
  char     tfr_id[16];  // the TFR it is (or was last) inside; kept after it leaves
  uint32_t first_ms, last_ms;
  uint16_t msgs;
  int8_t   peak_rssi;
  float    max_height;   // NAN until known
  bool     tfr_ever;     // was inside a TFR at some point (for the match log)
  bool     emerg_ever;   // reported status 3 (emergency) at some point
  // UA classification from the System message, F3411 raw codes: type 1 is
  // EU, with its category and class; 0 everywhere is "undeclared".
  uint8_t  class_type, cat_eu, class_eu;
  // Duplicate suppression for the serial feed, per source (wifi/nan/ble):
  // a transmitter repeating an identical frame is reported once a second.
  uint32_t emit_hash[3];
  uint32_t emit_ms[3];
};

// One table for the whole program. Defined in rx_core.h (included exactly
// once, by the sketch); a `static` here would hand every source file that
// includes this header its own empty copy — the radio core filling one while
// the screen reads another.
//
// g_tracks is what screens read. On the device the radio core decodes on
// its own task into a private live table (g_trk_live) and copies it into
// g_tracks from the loop, so a screen never sees a half-written contact;
// on the host tests both names are the same table. On the device both are
// allocated at start-up (PSRAM when fitted, see ext_ram.h), so size them
// with TRK_TABLE_BYTES, never sizeof(g_tracks).
#if defined(ESP_PLATFORM)
extern Track* g_tracks;          // TRK_MAX entries
#else
extern Track g_tracks[TRK_MAX];  // the host harnesses define it as an array
#endif
#define TRK_TABLE_BYTES (sizeof(Track) * TRK_MAX)
extern Track* g_trk_live;
/// A contact is about to leave the table (expired or evicted): the match
/// log's chance to record it. Defined in rx_core.h.
void trk_on_end(const Track* t);

/// `id_type` is the ODID ID type of `uas` (ignored without one). A CAA
/// registration (type 2) names the same aircraft as the serial it flies
/// with, so it joins the contact heard on the address rather than start
/// one: keyed as uas2 beside a serial, or as uas until the serial arrives.
static inline Track* tracker_upsert(const uint8_t* mac, const char* uas,
                                    uint32_t now, bool* created, uint8_t id_type = 1) {
  if (created) *created = false;
  bool has_id = uas && uas[0];
  bool alt = has_id && id_type == 2;
  Track* by_uas = nullptr;
  Track* by_mac = nullptr;
  Track* free_slot = nullptr;
  Track* oldest = nullptr;
  for (int i = 0; i < TRK_MAX; i++) {
    Track* t = &g_trk_live[i];
    if (!t->used) {
      if (!free_slot) free_slot = t;
      continue;
    }
    if (has_id && (strncmp(t->uas, uas, sizeof(t->uas)) == 0 ||
                   (alt && strncmp(t->uas2, uas, sizeof(t->uas2)) == 0))) by_uas = t;
    bool match_mac = (memcmp(t->mac, mac, 6) == 0);
    if (!match_mac) {
      for (uint8_t m = 0; m < t->alt_mac_count; m++) {
        if (memcmp(t->alt_macs[m], mac, 6) == 0) {
          match_mac = true;
          break;
        }
      }
    }
    if (match_mac) by_mac = t;
    if (!oldest || t->last_ms < oldest->last_ms) oldest = t;
  }
  // Identity wins over hardware address. Falling back to the MAC is only
  // safe when there is no identity conflict — otherwise two aircraft that
  // share a MAC (randomised addresses, a spoofer, or one transmitter
  // sending several UAS IDs) collapse into a single contact whose ID
  // flip-flops, hiding one of them entirely. The one identity that never
  // conflicts is a registration beside a serial (or a serial beside a
  // registration heard first): the two names of one aircraft.
  Track* t = by_uas;
  if (!t && by_mac) {
    if (!has_id || !by_mac->uas[0]) t = by_mac;
    else if (alt && by_mac->uas_type != 2 && !by_mac->uas2[0]) t = by_mac;
    else if (!alt && by_mac->uas_type == 2) t = by_mac;
  }
  if (!t) {
    t = free_slot ? free_slot : oldest;   // LRU eviction, never slot 0 forever
    if (t->used) trk_on_end(t);
    memset(t, 0, sizeof(*t));
    t->used = true;
    t->first_ms = now;
    t->height = NAN;
    t->alt_geo = NAN;
    t->speed = NAN;
    t->heading = NAN;
    t->max_height = NAN;
    t->peak_rssi = -127;
    if (created) *created = true;
  }
  // One aircraft shows up under several addresses -- its Wi-Fi SA, its BLE
  // random-static address, a NAN cluster member -- and a Location-only
  // frame carries no UAS ID to re-match on. So every address seen stays
  // attached to the contact: `mac` is the most recent, the rest wait in
  // alt_macs (oldest evicted first). When an old address comes back the
  // previous primary takes its slot, so the remembered set never shrinks;
  // forgetting the previous primary here is exactly the split into two
  // contacts that this table exists to prevent.
  if (memcmp(t->mac, mac, 6) != 0) {
    static const uint8_t zero_mac[6] = {0};
    int slot = -1;
    for (int m = 0; m < t->alt_mac_count; m++)
      if (memcmp(t->alt_macs[m], mac, 6) == 0) { slot = m; break; }
    if (memcmp(t->mac, zero_mac, 6) != 0) {   // a fresh slot has nothing to keep
      if (slot >= 0) {
        // The returning address leaves the list and the outgoing primary
        // joins it at the end, so the list stays oldest-first for eviction.
        memmove(t->alt_macs[slot], t->alt_macs[slot + 1], (size_t)(t->alt_mac_count - slot - 1) * 6);
        memcpy(t->alt_macs[t->alt_mac_count - 1], t->mac, 6);
      } else if (t->alt_mac_count < TRK_ALT_MACS) {
        memcpy(t->alt_macs[t->alt_mac_count++], t->mac, 6);
      } else {
        memmove(t->alt_macs[0], t->alt_macs[1], (TRK_ALT_MACS - 1) * 6);
        memcpy(t->alt_macs[TRK_ALT_MACS - 1], t->mac, 6);
      }
    }
    memcpy(t->mac, mac, 6);
  }
  if (has_id) {
    if (alt && t->uas[0] && t->uas_type != 2) {
      strncpy(t->uas2, uas, sizeof(t->uas2) - 1);     // the registration beside the serial
      t->uas2[sizeof(t->uas2) - 1] = 0;
    } else {
      if (!alt && t->uas_type == 2 && t->uas[0]) {     // the serial arrives: the registration steps aside
        memcpy(t->uas2, t->uas, sizeof(t->uas2));
      }
      strncpy(t->uas, uas, sizeof(t->uas) - 1);
      t->uas[sizeof(t->uas) - 1] = 0;
      t->uas_type = alt ? 2 : (id_type ? id_type : 1);
    }
  }
  t->last_ms = now;
  t->msgs++;
  return t;
}

/// Drop contacts unheard for TRK_EXPIRE_MS. Returns how many went. The
/// difference is signed: the decode task stamps last_ms with a millis()
/// newer than the loop's `now`, and unsigned it would wrap and expire the
/// contact that was just refreshed.
static inline int tracker_expire(uint32_t now) {
  int n = 0;
  for (int i = 0; i < TRK_MAX; i++) {
    Track* t = &g_trk_live[i];
    if (t->used && (int32_t)(now - t->last_ms) > (int32_t)TRK_EXPIRE_MS) {
      trk_on_end(t);
      t->used = false;
      n++;
    }
  }
  return n;
}

/// Short badge for an authentication state. "ID" is deliberate: the
/// signature covers the drone's identity, never its reported position.
static inline const char* track_auth_badge(uint8_t st) {
  // Plain ASCII so every board's font renders it identically; the boards
  // add colour (green / red / amber / grey) — never a different word.
  switch (st) {
    case 3:  return "ID OK";    // signature valid (identity only, never position)
    case 4:  return "ID BAD";   // signature invalid: a security event
    case 1:  return "ID..";     // pages still arriving
    case 2:  return "ID?";      // signed, key not trusted
    case 5:  return "TEST";     // signed with the public test key: not an identity
    default: return "";
  }
}
